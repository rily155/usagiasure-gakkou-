<?php
$db_host='localhost';
$db_port='3306';
$db_name='bakuhu-n';
$db_user='root';
$db_password='password';
$dsn='mysql:host=localhost;dbname='