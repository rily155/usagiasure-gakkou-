<?php
echo("バクフーン");
echo("<button>ボタン</button>");
?>