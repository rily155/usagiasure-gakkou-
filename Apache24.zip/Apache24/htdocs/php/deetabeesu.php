<?php



try {
    $host = "localhost";
    $dbname = "bakuhu-n";
    $user = "root";
    $password = "password";

    $pdo = new PDO(
        "mysql:host=$host;dbname=$dbname;charset=utf8mb4",
        $user,
        $password
    );

    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    $sql = "SELECT id, mozi FROM taipingu";

    $stmt = $pdo->query($sql);

    // データを配列に格納
    $data = [];
    $row = $stmt->fetchAll(PDO::FETCH_ASSOC); 
        var_dump($row);

} catch (PDOException $e) {
    // エラーレスポンス
    http_response_code(500);
    echo json_encode([
        'status' => 'error',
        'message' => 'データベース接続エラー：' . $e->getMessage()
    ], JSON_UNESCAPED_UNICODE);
}
?>