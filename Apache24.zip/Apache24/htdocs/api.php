<?php

header('Content-Type: application/json; charset=utf-8');

try {
    $host = "localhost";
    $dbname = "bakuhu-n";
    $user = "root";
    $password = "password";

    $pdo = new PDO(
        "mysql:host=$host;dbname=$dbname;charset=utf8mb4",
        $user,
        $password
    );

    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    $sql = "SELECT id, mozi FROM taipingu";

    $stmt = $pdo->query($sql);

    // データを配列に格納
    $data = [];
    while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
        $data[] = [
            'id' => (int)$row['id'],
            'mozi' => $row['mozi']
        ];
    }

    // JSONとして出力
    echo json_encode([
        'status' => 'success',
        'data' => $data,
        'count' => count($data)
    ], JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);

} catch (PDOException $e) {
    // エラーレスポンス
    http_response_code(500);
    echo json_encode([
        'status' => 'error',
        'message' => 'データベース接続エラー：' . $e->getMessage()
    ], JSON_UNESCAPED_UNICODE);
}
?>